def get_github_link():
    return "https://github.com/italomarca"
