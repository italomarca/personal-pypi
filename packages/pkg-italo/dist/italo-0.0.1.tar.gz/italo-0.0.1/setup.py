import setuptools

# with open("README.md", "r", encoding="utf-8") as fh:
#     long_description = fh.read()

setuptools.setup(
    name="italo",
    version="0.0.1",
    author="Italo Marca",
    author_email="italomarca@icloud.com",
    description="A small example package",
    packages=setuptools.find_packages(),
    python_requires=">=3.6"
)
